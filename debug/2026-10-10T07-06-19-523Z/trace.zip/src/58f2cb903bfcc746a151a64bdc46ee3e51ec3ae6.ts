/**
 * The frame pump.
 *
 * This is the loop the whole framework is built around:
 *
 *   for each frame index n:
 *     logical time = n / fps
 *     sample the motion track at that time
 *     apply it to the page
 *     capture the page
 *     hand the frame to the encoder
 *
 * Note what is *not* in that loop: any reading of the wall clock. Frame N is defined by its
 * index and nothing else. If capture is slow, the pump simply takes longer in wall-clock terms -
 * the video is identical. That is the difference between a reproducible renderer and a
 * real-time one, and it is the whole reason Playwright's screencast was rejected (see
 * ARCHITECTURE_AUDIT.md §5.1-5.2, where the screencast was measured drawing no cursor and
 * emitting wall-clock-timed frames).
 *
 * ### How it runs concurrently with the script
 *
 * The user script and the pump are separate async flows. `start()` launches the pump loop and
 * returns immediately; the script then awaits whatever it likes. Actions that animate register
 * an animation on the motion track and await the *logical clock*, which only advances as the
 * pump produces frames. So a `pause(1000)` genuinely renders 30 frames of stillness rather than
 * the script simply blocking.
 *
 * ### Capture
 *
 * CDP `Page.captureScreenshot` rather than `page.screenshot()`. It returns base64 directly,
 * avoiding an extra decode, and it is the path the throughput benchmark in the audit measured.
 * Capture is resolution-independent (~16ms, one compositor frame); encoding is not, which is why
 * the layout-viewport split exists.
 */

import type { CDPSession, Page } from 'playwright';

import type { VideoConfig } from '../config/config.js';
import type { Encoder } from '../recorder/encoder.js';
import { VideoRecorderError } from '../runtime/errors.js';
import type { LogicalClock } from '../runtime/clock.js';
import type { MotionTrack } from '../motion/track.js';
import { timeForFrame } from '../config/config.js';

/** Applies the sampled motion state to the page. Injected so it can be faked in tests. */
export type ApplyFrame = (frameIndex: number, atMs: number) => Promise<void>;

/**
 * Sentinel distinguishing "the capture timed out" from a real frame, which is a Buffer.
 * A distinct symbol rather than `null`, so a null frame and a timed-out capture stay separable.
 */
const CAPTURE_TIMED_OUT = Symbol('capture-timed-out');

/**
 * How long a single capture may take before it is treated as stuck.
 *
 * Captures normally take ~16ms — one compositor frame. Navigation takes 100-500ms and is skipped
 * by event rather than waited on, so anything past this bound is a capture that will not return.
 */
const CAPTURE_TIMEOUT_MS = 3_000;

/**
 * Hand control back to the event loop.
 *
 * Used by the skip path so the pump cannot starve the navigation it is waiting on.
 */
function yieldToEventLoop(): Promise<void> {
  return new Promise((resolve) => {
    const handle = setImmediate(resolve);
    handle.unref?.();
  });
}

export interface FramePumpOptions {
  page: Page;
  clock: LogicalClock;
  track: MotionTrack;
  encoder: Encoder;
  config: VideoConfig;
  /** Push the sampled motion onto the page. Defaults to no-op for a minimal pump. */
  applyFrame?: ApplyFrame;
  /** Receives every frame, for frame dumping and live progress. */
  onFrame?: (frameIndex: number, atMs: number) => void;
}

export interface FramePumpStats {
  framesWritten: number;
  /** Wall-clock milliseconds spent inside the render loop. */
  elapsedMs: number;
  /** Milliseconds per frame, wall-clock. The performance figure the plan asks for. */
  msPerFrame: number;
  /** How fast the pipeline ran relative to real time. Above 1 means faster than realtime. */
  throughput: number;
}

/**
 * Drives logical time and frame capture.
 *
 * Created by {@link createFramePump}, driven with {@link FramePump.run} until the script
 * finishes.
 */
export class FramePump {
  readonly #options: FramePumpOptions;

  #running = false;
  #stopped = false;
  #failure: Error | undefined;
  #framesWritten = 0;
  #startedAtMs = 0;

  /**
   * True between a main-frame navigation starting and its document settling.
   *
   * Capture during that window hangs forever — measured, not assumed — so it must be detected
   * rather than waited on.
   */
  #navigationInFlight = false;

  constructor(options: FramePumpOptions) {
    this.#options = options;

    const { page } = options;
    page.on('framenavigated', (frame) => {
      if (frame === page.mainFrame()) this.#navigationInFlight = true;
    });
    // Both of these mean the new document is present and settled.
    page.on('domcontentloaded', () => {
      this.#navigationInFlight = false;
    });
    page.on('load', () => {
      this.#navigationInFlight = false;
    });
  }

  /** Frames successfully written so far. */
  framesWritten(): number {
    return this.#framesWritten;
  }

  /** The error that stopped the pump, if any. */
  failure(): Error | undefined {
    return this.#failure;
  }

  /**
   * Pump frames until {@link FramePump.stop} is called.
   *
   * Resolves when the loop ends. Rejects only on a capture or encoder failure — a script error
   * is the caller's business and arrives through `stop()`, not through here.
   */
  async run(): Promise<void> {
    const { page, clock, encoder, config, applyFrame, onFrame } = this.#options;
    const cdp = await page.context().newCDPSession(page);

    this.#running = true;
    this.#startedAtMs = Date.now();

    const capture = this.#makeCapture(cdp, config);

    try {
      let frameIndex = 0;

      while (!this.#stopped) {
        const atMs = timeForFrame(frameIndex, config.fps);

        if (applyFrame) {
          await applyFrame(frameIndex, atMs);
        }

        // Capturing while a navigation is in flight does not fail — it *hangs forever*, which
        // was measured, not assumed. So navigations are detected up front and the frame is
        // skipped, with a bounded race as a backstop for anything the events miss.
        if (this.#navigationInFlight) {
          // Yield to the event loop. Without this the skip path is a tight synchronous loop,
          // which starves the very navigation we are waiting on: `load` never fires, the flag
          // never clears, and the pump spins forever. That livelock presents as a render that
          // simply stops after one or two frames.
          await yieldToEventLoop();
          continue;
        }

        const frame = await this.#captureOrSkip(page, capture);

        if (frame === null) {
          // Skipped. Logical time deliberately does *not* advance: the frame index is the
          // definition of time, so a frame that was not captured must not consume one. If it
          // did, the video's length would depend on how long each navigation happened to take,
          // which is exactly the machine-dependence this design exists to remove.
          await yieldToEventLoop();
          continue;
        }

        clock.advanceTo(timeForFrame(frameIndex, config.fps));
        await encoder.write(frame);
        this.#framesWritten++;
        onFrame?.(frameIndex, atMs);

        // Advance to the *end* of this frame's interval, not the frame's presentation time.
        // Frame k is shown at k/fps, but after writing it the video has consumed (k+1)/fps of
        // time. Advancing only to k/fps makes every pause one frame long: pause(1000) at 30fps
        // would emit 31 frames instead of 30.
        clock.advanceTo(timeForFrame(frameIndex + 1, config.fps));

        frameIndex++;
      }

      await encoder.finish();
    } catch (error) {
      this.#failure = error instanceof Error ? error : new Error(String(error));
      // Nothing will advance logical time again, so every pending `wait()` must be failed
      // rather than left hanging. This is what turns a dead pump into a reported error rather
      // than a render that never finishes.
      clock.rejectPending(this.#describeFailure());
      throw this.#failure;
    } finally {
      this.#running = false;
      await cdp.detach().catch(() => undefined);
    }
  }

  /**
   * Capture a frame, or report that there is nothing to capture yet.
   *
   * Two cases return null rather than throwing, and everything else propagates. A broken CDP
   * session must never be mistaken for "the page has not loaded yet", because that would turn a
   * crashed render into a silently short video.
   */
  async #captureOrSkip(page: Page, capture: () => Promise<Buffer>): Promise<Buffer | null> {
    if (page.isClosed()) return null;

    // Backstop. Captures normally take ~16ms; a navigation takes 100-500ms. Anything past this
    // is a stuck capture, and abandoning it is safer than blocking the run forever. The abandoned
    // promise is given its own catch so it cannot surface later as an unhandled rejection.
    const timeout = new Promise<typeof CAPTURE_TIMED_OUT>((resolve) => {
      const handle = setTimeout(() => resolve(CAPTURE_TIMED_OUT), CAPTURE_TIMEOUT_MS);
      handle.unref?.();
    });

    const attempt = capture().then(
      (frame) => frame,
      (error: unknown) => {
        throw error;
      },
    );

    try {
      const result = await Promise.race([attempt, timeout]);
      return result === CAPTURE_TIMED_OUT ? null : result;
    } catch (error) {
      void attempt.catch(() => undefined);

      // Before the first navigation the page is about:blank, which has no renderer target and
      // reports either "Not attached to an active page" or "Unable to capture screenshot". Those
      // frames are white anyway, so they are skipped rather than treated as failures.
      //
      // The URL is the signal, not `document.readyState`: about:blank reports readyState
      // 'complete', which made an earlier version of this check rethrow and kill every run.
      const url = page.url();
      if (url === 'about:blank' || url === '') return null;

      // Anything after that is a genuine capture failure and belongs in the run manifest.
      throw error;
    }
  }

  /** Stop after the current frame. */
  stop(): void {
    this.#stopped = true;
  }

  /** Whether the loop is still going. */
  isRunning(): boolean {
    return this.#running;
  }

  /** Performance figures for the manifest. */
  stats(): FramePumpStats {
    const elapsedMs = Math.max(1, Date.now() - this.#startedAtMs);
    const videoMs =
      this.#framesWritten > 0 ? timeForFrame(this.#framesWritten, this.#options.config.fps) : 0;

    return {
      framesWritten: this.#framesWritten,
      elapsedMs,
      msPerFrame: elapsedMs / Math.max(1, this.#framesWritten),
      // Video time over wall time. The plan's headline performance number.
      throughput: videoMs / elapsedMs,
    };
  }

  /**
   * Capture one frame.
   *
   * JPEG is the default because it encodes roughly 3x faster and pipes about 4x fewer bytes,
   * and capture-plus-encode throughput is what this design depends on. PNG is available for the
   * golden determinism suite, which compares lossless frames.
   */
  #makeCapture(cdp: CDPSession, config: VideoConfig): () => Promise<Buffer> {
    const { frameFormat, frameQuality } = config.recorder;

    return async () => {
      const { data } = await cdp.send('Page.captureScreenshot', {
        format: frameFormat,
        // Quality is meaningless for PNG, and sending it makes Chromium fall back to PNG
        // regardless of what was asked for.
        ...(frameFormat === 'jpeg' ? { quality: frameQuality } : {}),
        // Viewport-only. `captureBeyondViewport` would silently stitch a full-page image whose
        // height has nothing to do with the configured frame size.
        captureBeyondViewport: false,
        fromSurface: true,
      });

      if (typeof data !== 'string') {
        throw new VideoRecorderError('Frame capture returned no image data.');
      }
      return Buffer.from(data, 'base64');
    };
  }

  /** Human-readable cause for the pending-wait rejections. */
  #describeFailure(): string {
    const message = this.#failure?.message ?? 'unknown error';
    return `The frame pump stopped after ${this.#framesWritten} frames: ${message}`;
  }
}

/** Build a pump. */
export function createFramePump(options: FramePumpOptions): FramePump {
  return new FramePump(options);
}
